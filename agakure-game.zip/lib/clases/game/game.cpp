/* 
 Autor:    Doltrox 
 archivo:  game.cpp
 version:  2.0
 licencia: GPL
 año:      2016
 email:    ----

                 .___     .__   __                       
               __| _/____ |  |_/  |________  _______  ___
              / __ |/  _ \|  |\   __\_  __ \/  _ \  \/  /
             / /_/ (  <_> )  |_|  |  |  | \(  <_> >    < 
             \____ |\____/|____/__|  |__|   \____/__/\_ \
                   \/                                  \/

 */


#include "game.h"
/*
int CgameSund::load(char cad[]){
    int i=0;
    music=Mix_LoadMUS(cad);
    if(!music) {
        printf("Mix_LoadMUS(\"%s\"): %s\n",cad, Mix_GetError());
        // this might be a critical error...
        i=1;
    }
    return i;
}

void Cgame::unload(){
    Mix_FreeMusic(music);
}
*/

/* 
iniciar el sdl
1:  video
2:  audio
3:  timer
-1: todos
*/

Cgame::Cgame(){
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER | SDL_INIT_TIMER) < 0 )
            {
                printf("no se puede iniciar SDL %s\n",SDL_GetError());
                exit(1);
            }


}
Cgame::Cgame(int i){

        HSCREEN = 600;
        WSCREEN = 600;
        SCREEN_BPP = 32;

    switch(i){
        case 1:
            if (SDL_Init(SDL_INIT_VIDEO) < 0 )
            {
                printf("no se puede iniciar SDL %s\n",SDL_GetError());
                exit(1);
            }
        case 2:
            if (SDL_Init(SDL_INIT_AUDIO) < 0 )
            {
                printf("no se puede iniciar SDL %s\n",SDL_GetError());
                exit(1);
            }
        case 3:
            if (SDL_Init(SDL_INIT_TIMER) < 0 )
            {
                printf("no se puede iniciar SDL %s\n",SDL_GetError());
                exit(1);
            }
        case 10:
            if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER | SDL_INIT_TIMER) < 0 )
            {
                printf("no se puede iniciar SDL %s\n",SDL_GetError());
                exit(1);
            }


            // iniciando sdl_mixer (nuestro reproductor :D )
    if (Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,4096)<0)
    {
        printf("no se puede iniciar SDL_mixer %s\n",Mix_GetError());
        exit(1);
    }

    
    }

}

//activar el modo de video
int Cgame::video_init(){
    screen = SDL_SetVideoMode(WSCREEN , HSCREEN, SCREEN_BPP, SDL_SWSURFACE /*| SDL_FULLSCREEN*/);
    if (screen == NULL)
    {
        printf("no se puede iniciar el modo grafico %s\n",SDL_GetError());
        exit(1);
    }
}

int Cgame::sonido_init(){
    if (Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,4096)<0)
    {
        printf("no se puede iniciar SDL_mixer %s\n",Mix_GetError());
        exit(1);
    }
}

int Cgame::titulo(char cad[]){
    SDL_WM_SetCaption(cad,NULL);
}
void Cgame::dibujarPantalla(){
    SDL_Flip(screen);
}

/*
int agregarTrack(char *ruta){
    if (numSund < 0)
    {
        numSund=0;
    }
    SONIDO = new gameSund[++numSund];
    selectSund = numSund;
    SONIDO[selectSund].load(ruta);
}

int playTrack(){
    if(Mix_PlayMusic(SONIDO[selectSund].music, -1) == -1) {
        printf("Mix_PlayMusic: %s\n", Mix_GetError());
    // well, there's no music, but most games don't break without music...
    }
}

int freeTrack(){
    SONIDO[selectSund].unload();
}

void pauseTrack(){
    Mix_PauseMusic();
}

void resumeTrack(){
    Mix_ResumeMusic();
}

void selectTrack(int i){
    if (selectSund > i){
        selectSund = i;
    }
}
*/

void Cgame::drawScreen(){
    SDL_Flip(screen);
    for (int i = 0; i < Vbackgrounds.size(); ++i)
   {
       Vbackgrounds[i].draw(screen);
   }



   for (int i = 0; i < Vsprites.size(); ++i)
   {
       Vsprites[i].draw(screen);
   }
}

void Cgame::addSprite(Csprite *sp,std::string name){
    Vsprites.push_back(*sp);
    VnameSprites.push_back(name);
}

Csprite* Cgame::getSprite(std::string name){
    for (int i = 0; i < VnameSprites.size(); ++i)
    {
        if (name == VnameSprites[i])
        {
            return &Vsprites[i];
        }
    }
}