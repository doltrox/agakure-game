/* 
 Autor:    Doltrox 
 archivo:  game.h
 version:  2.0
 licencia: GPL
 año:      2016
 email:    ----

                 .___     .__   __                       
               __| _/____ |  |_/  |________  _______  ___
              / __ |/  _ \|  |\   __\_  __ \/  _ \  \/  /
             / /_/ (  <_> )  |_|  |  |  | \(  <_> >    < 
             \____ |\____/|____/__|  |__|   \____/__/\_ \
                   \/                                  \/

 */


#ifndef GAME_H
#define GAME_H
#include </usr/include/SDL/SDL.h>
#include </usr/include/SDL/SDL_mixer.h>
#include <vector>
#include <string>
//#define tue 0
//#define false 1
// archivos permitidos: WAVE, MOD, MIDI, OGG, MP3, FLAC
/*class gameSund
{
public:
	Mix_Music *music;
	int load(char *);
	void unload();
	
};
*/

class Cgame
{
private:
	int SCREEN_BPP;
	//int numSund;
	//int selectSund;
public:
	 int FRAMES_PER_SECOND;
	SDL_Surface *screen;
	int HSCREEN;
	int WSCREEN;
	std::vector<Csprite> Vsprites;
	std::vector<std::string> VnameSprites;

	std::vector<Cbackground> Vbackgrounds;

	//gameSund *SONIDO;
	Cgame(int o);
	Cgame();
	void setScreenH(int h){HSCREEN = h;}
	void setScreenW(int w){WSCREEN = w;}
	int video_init();
	int sonido_init();
	int titulo(char *);
	void dibujarPantalla();
	void drawScreen();
	void addSprite(Csprite *sp,std::string name);
	Csprite* getSprite(std::string name);
	/* game */
};
#endif