#include "sprite.h"
#include </usr/include/SDL/SDL.h>
//Cframe class implementacion

	//cargar image
	void Cframe::load(char *path){
		img=SDL_LoadBMP(path);
		SDL_SetColorKey(img,SDL_SRCCOLORKEY|SDL_RLEACCEL,SDL_MapRGB(img->format,255,0,255));
		img=SDL_DisplayFormat(img);
	}

	//descargar de memoria
	void Cframe::unload(){
		SDL_FreeSurface(img);
	}



//sprite class implementacion

	//inicializa el array de frames
	Csprite::Csprite(int nFrames){
		sprite = new Cframe[nFrames];
		numFrames=nFrames;
		count=0;
		DireccX=0;
		tempPosx = 0;
		tempPosy = 0;
		inMoviment = 0;
	}

	//inicializa un array de un solo frame
	Csprite::Csprite(){
		int nFrames=1;
		sprite = new Cframe[nFrames];
		numFrames=nFrames;
		count=0;
		DireccX=0;
	}
	void Csprite::updateFrames(int nFrames){
		sprite=NULL;
		sprite = new Cframe[nFrames];
		numFrames=nFrames;
		count=0;
	}

	//descarga el sprite de la memoria
	void Csprite::salir(){
		for (int i = 0; i <=numFrames; ++i)
		{
			sprite[i].unload();
		}
	}

	//agrega un frame al sprite
	void Csprite::agregarFrame(Cframe frame){
		if (count<numFrames)
		{
			sprite[count]=frame;
			frameSelect=count;
			count++;
		}
	}

	//selecciona el frame que se va a dibujar
	void Csprite::seleccionarFrame(int nFrames){
		if (nFrames<=numFrames)
		{
			estado=nFrames;
		}
	}

	//carga imagen completa que incluye todos los frames
	void Csprite::loadIMG(char Ruta[],int fr_ames){
	Cframe FRAME;
    FRAME.load(Ruta);
    agregarFrame(FRAME);
    printf("añadiendo imagen %s\n",Ruta);

			FR_ames[frameSelect]=fr_ames;
}

	//corta la imagen para mostrarla
	 void Csprite::apply_surface(
            int x, // x screen
            int y, // y screen
            SDL_Surface* source, // imagen
            SDL_Surface* destination, //screen
            SDL_Rect clip //rectangulo con los parametros
            )
        {
        //Holds offsets
        SDL_Rect Rectangulo;

        //Get offsets
        Rectangulo.x = x;
        Rectangulo.y = y;

        //Blit
        SDL_BlitSurface( source, &clip, destination, &Rectangulo );
        }

	//copia el sprite a la superficie pasada como parametro
	void Csprite::draw(SDL_Surface *superficie){
		int dibujarr=0;
		if (esVisible == 1)
		{
			dibujarr=1;
		}
		if (solido==1)
		{
			dibujarr=1;
		}
		if (dibujarr==1)
		{

			if (FR_ames[estado] > 1)
        	{
        		if (FR_ames[estado] == count_FR_ames[estado])
        		{
        			count_FR_ames[estado]=0;
        		}else{
        			Spritex(Spritew()*count_FR_ames[estado]);
        			count_FR_ames[estado]++;
        		}
        	}else{

        		Spritex(0);
        	}

			SDL_Rect clipJump;
			clipJump.x = Spritex(); //posicion  x:0 de la imagen
        	clipJump.y = Spritey(); //posicion y:122 de la imagen
        	clipJump.w = Spritew(); //ancho del pedazo de imagen a mostrar
        	clipJump.h = Spriteh(); //alto del pedazo de imagen a mostrar
        apply_surface(
            posx, // x screen
            posy, // y screen
            sprite[estado].img,	//imagen
            superficie, //screen
            clipJump 	//rectangulo con los parametros
            );


		}
	
	}

	// devuelve 0 si hay una colision con el sprite pasado por parametro sino devuelve 1
	int Csprite::colision(Csprite *sp){
		int w1,h1,y1,x1;
		int w2,h2,y2,x2;

		//datos de sprite actual
		h1=geth();	//altura del sprite
		w1=getw();	//ancho del sprite
		x1=getx();	//posicion x del sprite
		y1=gety();	//posicion y del sprite

		//datos de sprite 2 o sprite pasado por parametro
		h2=sp->Spriteh();	//altura del sprite 
		w2=sp->Spritew();	//ancho del sprite 
		x2=sp->getx();	//posicion x del sprite 
		y2=sp->gety();	//posicion x del sprite 

		if (((x1+w1)>x2) && ((y1+h1)>y2) && ((x2+w2)>x1) && ((y2+h2)>y1))
		{// lado Dr           abajo           lado izq        arriba

			return 0;
		}else{
			return -1;
		}

	}

	//estas funciones mueve al sprite hacia una posicion y consta de usa serie de parametros
	//pixel:  la cantidad de pixeles a mover: el salto de x a x posicion
	//screenMargen: hasta que pixel del screen podra moverse el sprite hacia arriba,abajo,derecha,izquierda
	//frame: el numero de frame que se mostrara, si es NULL se deja el frame actual
	//recuerden que desde arriba hacia abajo de miden los pixeles 
	//ejemplo en una ventana de 500-680, 500 seria el ultimo pixel desde arriba hacia abajo
	//
	//ADVERTENCIA
	//si es hacia abajo se debe pasar: pixel, y el alto del screen en el ejemplo seria 500
	//si es hacia la derecha se debe pasar: pixel, y el ancho del screen 
	//d
	int Csprite::movW(int pixel,int screenMargen,int framme){
		if (framme != 0)
		{
			seleccionarFrame(framme);
		}
		int y1=gety();	//posicion y del sprite
		if (y1 > screenMargen)
		{
			sety( y1 - pixel);
		}
	}
	int Csprite::movS(int pixel,int screenMargen,int framme){
		if (framme != 0)
		{
			seleccionarFrame(framme);
		}
		int y1=gety();
		int h1=geth();
		if (y1 < screenMargen - h1)
		{
			sety(y1 + pixel);
		}
	}
	int Csprite::movA(int pixel,int screenMargen,int framme){
		if (framme != 0)
		{
			seleccionarFrame(framme);
		}
		int x1=getx();	//posicion y del sprite
		if (x1 > screenMargen)
		{
			setx( x1 - pixel);
		}
	}
	int Csprite::movD(int pixel,int screenMargen,int framme){
		if (framme != 0)
		{
			seleccionarFrame(framme);
		}
		int x1=getx();
		int w1=getw();
		if (x1 < screenMargen - w1)
		{
			setx(x1 + pixel);
		}
	}