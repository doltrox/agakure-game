#ifndef  CSPRITE
#define  CSPRITE
#include </usr/include/SDL/SDL.h>
//#define tue 0
//#define false 1
// Cframe reprecenta un frame independiente de un sprite
class Cframe
{
public:	
	//para el valor de retorno
	SDL_Surface *img;

	//cargar image
	void load(char *path);

	//descarga un frame de la memoria
	void unload();
};



// la clase sprite, se forma por un array de frames;
class Csprite
{
private:
	int posx,posy;
	
	int solido;
	int colisiono;
	int esVisible;
		int Impulsoarriba;
		int Impulsoabajo;
		int Impulsoizquierda;
		int Impulsoderecha;
	int Mobible;

	int Sx;
	int Sy;
	int Sw;
	int Sh;

public:
	Cframe *sprite;
	int count;
	int numFrames;
	int FR_ames[100];
	int count_FR_ames[100];
	int frameSelect;
	int estado;
	int DireccX;
	short unsigned int tempPosx;
	short unsigned int tempPosy;
	short unsigned int inMoviment;
	//inizializa un sprite de nFrames
	Csprite(int nFrames);
	//inicializa un sprite de un solo frame
	Csprite();
	void updateFrames(int nFrames);
	//descarga el sprite de la memoria
	void salir();
	//agrega un frame al sprite
	void agregarFrame(Cframe frame);
	//selecciona el frame a ser dibujado en la pantalla
	void seleccionarFrame(int nFrames);

	void loadIMG(char*,int);
	//retorna el numero de frames total
	int frames(){return count;}
	//posiciona el sprite en la posicion x pasada
	void setx(int x){posx=x;}
	//posicion el sprite en la posicion y pasada
	void sety(int y){posy=y;}
	//añade c a la posicion x del sprite
	void addx(int c){posx+=c;}
	//añade c a la posicion y del sprite
	void addy(int c){posy+=c;}
	//obtiene la posicion x del sprite
	int getx(){return posx;}
	//obtiene la posicion y del sprite
	int gety(){return posy;}
	//obtiene el ancho del sprite
	int getw(){return sprite[estado].img->w;}
	//obtiene el alto del sprite
	int geth(){return sprite[estado].img->h;}

	int  Spritex(){return Sx;};
	void Spritex(int i){Sx=i;};

	int  Spritey(){return Sy;};
	void Spritey(int i){Sy=i;};

	int  Spritew(){return Sw;};
	void Spritew(int i){Sw=i;};

	int  Spriteh(){return Sh;};
	void Spriteh(int i){Sh=i;};

	//corta la imagen para mostrarla
	void apply_surface(int x,int y,SDL_Surface* source,SDL_Surface* destination,SDL_Rect clip);
	//dibuja el sprite
	void draw(SDL_Surface *superficie);
	//mira si hay una colosion con el sprite (hay que pasar el otro sprite a evaluar)
	int colision(Csprite *sp);
	//mueve sprite pixeles hacia arriba no mas de ScreenMargen (hay que pasar el numero del frame a mostrar)
	int movW(int pixel,int screenMargen,int framme);
	int movS(int pixel,int screenMargen,int framme);
	int movA(int pixel,int screenMargen,int framme);
	int movD(int pixel,int screenMargen,int framme);

	//retorna si es un sprite solido
	int get_solido(){return solido;}
	//dar solides a un sprite
	int set_solido(){solido=1;}
	//dar colision a un sprite aun que no sea asi
	int set_colision(){colisiono=1;}
	//mirar si un sprite tiene el campo colision
	int get_colision(){return colisiono;}
	// dar/quitar visibilidad a un sprite (si no es visible no se dibujara en pantalla)
	void visible(int i){esVisible=i;}
	//retorna si un sprite es visible
	int visible(){return esVisible;}

	//dar impulso a un objeto sprite
	int ImpulsoAr(int Ar){Impulsoarriba=Ar;}
	int ImpulsoAb(int Ab){Impulsoabajo=Ab;}
	int ImpulsoIz(int Iz){Impulsoizquierda=Iz;}
	int ImpulsoDr(int Dr){Impulsoderecha=Dr;}

	int ImpulsoAr(){return Impulsoarriba;}
	int ImpulsoAb(){return Impulsoabajo;}
	int ImpulsoIz(){return Impulsoizquierda;}
	int ImpulsoDr(){return Impulsoderecha;}

	//dar campo movible a un sprite
	int mobible(int i){Mobible=i;}
	//obtener el camp mobible
	int mobible(){return Mobible;}


	/* CSPRITE */
};
#endif