#ifndef background_H
#define background_H 
class Cbackground
{
public:	
	//para el valor de retorno
	SDL_Surface *img;

	//cargar image
	void load(char *path);

	//descarga un frame de la memoria
	void unload();

	void apply_surface(int x,int y,SDL_Surface* source,SDL_Surface* destination,SDL_Rect clip);
	
	void draw(SDL_Surface *superficie);
};
#endif