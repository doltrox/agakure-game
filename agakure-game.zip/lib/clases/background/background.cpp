//Cbackground class implementacion

	//cargar image
	void Cbackground::load(char *path){
		img=SDL_LoadBMP(path);
		SDL_SetColorKey(img,SDL_SRCCOLORKEY|SDL_RLEACCEL,SDL_MapRGB(img->format,255,0,255));
		img=SDL_DisplayFormat(img);
	}

	//descargar de memoria
	void Cbackground::unload(){
		SDL_FreeSurface(img);
	}


	//corta la imagen para mostrarla
	 void Cbackground::apply_surface(
            int x, // x screen
            int y, // y screen
            SDL_Surface* source, // imagen
            SDL_Surface* destination, //screen
            SDL_Rect clip //rectangulo con los parametros
            )
        {
        //Holds offsets
        SDL_Rect Rectangulo;

        //Get offsets
        Rectangulo.x = x;
        Rectangulo.y = y;

        //Blit
        SDL_BlitSurface( source, &clip, destination, &Rectangulo );
        }

	void Cbackground::draw(SDL_Surface *superficie){
		SDL_Rect clipJump;
			clipJump.x = 0 ;//posicion  x:0 de la imagen
        	clipJump.y = 0 ;//posicion y:122 de la imagen
        	clipJump.w = img->w ;//ancho del pedazo de imagen a mostrar
        	clipJump.h = img->h ;//alto del pedazo de imagen a mostrar
        apply_surface(
            0, // x screen
            0, // y screen
            img,	//imagen
            superficie, //screen
            clipJump 	//rectangulo con los parametros
            );
	}