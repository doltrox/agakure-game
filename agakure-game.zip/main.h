#ifndef MAIN_H
#define MAIN_H
#include <stdio.h>
#include <string.h>
#include </usr/include/SDL/SDL.h>
#include </usr/include/SDL/SDL_mixer.h>
#include </usr/include/SDL/SDL_image.h>

#include "lib/clases/sprite/sprite.h"
#include "lib/clases/sprite/sprite.cpp"
#include "lib/clases/timer/timer.h"
#include "lib/clases/timer/timer.cpp"
#include "lib/clases/background/background.h"
#include "lib/clases/background/background.cpp"

#include "lib/clases/game/game.h"
#include "lib/clases/game/game.cpp"
#endif