#include "lib/clases/sprite/sprite.h"

Csprite mounstruo;

    char ruta_M_left[]="enemi-01-mov-left.bmp";
    char ruta_M_right[]="enemi-01-mov-right.bmp";

    mounstruo.updateFrames(2);
    mounstruo.loadIMG(ruta_M_right,2);
    mounstruo.loadIMG(ruta_M_left,2);

    mounstruo.visible(1);

    mounstruo.Spritew(50);
    mounstruo.Spriteh(59);
    mounstruo.Spritex(0);
    mounstruo.Spritey(0);

    mounstruo.setx(200);
    mounstruo.sety(300);

void inteligence(){
    
    //inteligencia artificial del malo se mueve de un lado a otro
    if (mounstruo.DireccX == 0)
    {
        mounstruo.setx(mounstruo.getx()+ (mounstruo.Spritew() / 2.f / 3));
        mounstruo.seleccionarFrame(0);
        if (mounstruo.getx() >= 600 - mounstruo.Spritew())
        {
        mounstruo.DireccX=1;
    }
        
        
    }

    if (mounstruo.DireccX == 1){
        mounstruo.setx(mounstruo.getx()- (mounstruo.Spritew() / 2.f / 3));
        mounstruo.seleccionarFrame(1);
        if (mounstruo.getx() < 1)
    {
        mounstruo.DireccX=0;
    }
        
    }
}
