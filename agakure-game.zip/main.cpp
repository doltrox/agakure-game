/* 
 Autor:    Doltrox 
 archivo:  main.cpp
 version:  2.0
 licencia: GPL
 año:      2016
 email:    ----

                 .___     .__   __                       
               __| _/____ |  |_/  |________  _______  ___
              / __ |/  _ \|  |\   __\_  __ \/  _ \  \/  /
             / /_/ (  <_> )  |_|  |  |  | \(  <_> >    < 
             \____ |\____/|____/__|  |__|   \____/__/\_ \
                   \/                                  \/

 */



#include "main.h"
#include <stdio.h>
#include <vector>

//la clase Cgame es el motor de juego 

//BACKGROUND,OBJETO,JUGADOR,BOT,OBJETO_IMPERATIVO
char aplicationName[]="agakureGameByDoltrox";
SDL_Event event;   //handler event pronto dentro de la clase Cgame
SDL_Surface *screen; //handler screen pronto dentro de la clase Cgame
Timer fps;           //handler fps pronto dentro de la clase Cgame
Cgame juego(10); // nivel de ejecucion 10 inicia todos los subsistemas


//declaracion de sprites 
Csprite player;
Csprite mounstruo;

// declaracion de backgrounds
Cbackground background;


//sonidos
/*

la gestion de sonido estara en una clase dentro de Cgame aun no implementada


//declarar un sonido simple

Mix_Chunk *sonidoSimple;
//cargar un sonido simple
sonidobala=Mix_LoadWAV("sound/disparo.wav");
    if (sonidobala == NULL)
    {
        printf("no se pudo cargarAudio disparo   %s\n",Mix_GetError());
        exit(1);
    }
//reproducir sonido simple
if (Mix_PlayChannel(3,sonidobala,0))
    {
        printf("no se pudo reproducir sonido %s\n",Mix_GetError());
    }

//declarar musica fondo
Mix_Music *sonido;

//cargar musica fondo

char name[]="dat.mp3";
    sonido=Mix_LoadMUS(name);
    if (sonido == NULL)
    {
        printf("no se cargo nada %s\n",SDL_GetError());
    }

//reproducir musica fondo
if (Mix_Playing(1)!=1)
            {
                    if (Mix_PlayMusic(sonido,0)==1)
                    {
                        printf("no se pudo reproducir sonido %s\n",Mix_GetError());
                    }
            }
*/

Mix_Music *sonido;




void iniSonido(){
    char name[]="sound/sound.wav";
    sonido=Mix_LoadMUS(name);
    if (sonido == NULL)
    {
        printf("no se cargo nada %s\n",SDL_GetError());
    }
}

void playSonido(){

    if (Mix_Playing(1)!=1)
            {
                    if (Mix_PlayMusic(sonido,-1)==1)
                    {
                        printf("no se pudo reproducir sonido %s\n",Mix_GetError());
                    }
            }
}

/* estas funciones son para definir los objetos que interactuaran asi como los eventos... */
void initSprites(){

    // player
    char ruta_blit1[]="Sprite-0001s.bmp";
    char ruta_blit2[]="Sprite-0002s.bmp";
    char ruta_blit3[]="Sprite-0003s.bmp";
    char ruta_blit4[]="Sprite-0004s.bmp";

    player.updateFrames(4); // colocar cuatro frames en el objeto
    //la ruta de la imagen , cuantos bloques tiene la imagen
    //si bien cada frame tiene mas de un dibujo llamados bloques por su forma cuadrada
    //y si colocamos cuantos bloques hay entonces se mostrara la animacion de lo contrario
    //solo se mostrara 1 solo bloque por lo que no corre la animacion
    player.loadIMG(ruta_blit1,0); // frame 0 
    player.loadIMG(ruta_blit2,0); // frame 1
    player.loadIMG(ruta_blit3,0); // frame 2
    player.loadIMG(ruta_blit4,0); // frame 3

    player.visible(1); // hacer visible(dibujable) el objeto

    //definimos que parte de la imagen se va a mostrar "definimos el bloque que se mostrara en cada frame"

    player.Spritew(30);   //ancho 30 pixeles
    player.Spriteh(66);   //alto 66 pixeles
    player.Spritex(0);    //comienza a dibujar a partir de 0 X
    player.Spritey(0);    //comienza a dibujar a partir de 0 y
    // estos dos ultimos son manipulables si tu imagen no esta centrada

    //establecer cordenadas de posicionamiento del objeto en la pantalla
    player.setx(300);
    player.sety(100);

    //añadir el sprite ya configurado al motor de juego 
    //ademas le añadimos un nombre x para usarlo como controlador luego
    //en este caso su nombre es "player"
    juego.addSprite(&player,"player");

/////////  mounstruo prueba //////
    char ruta_M_left[]="enemi-01-mov-left.bmp";
    char ruta_M_right[]="enemi-01-mov-right.bmp";

    mounstruo.updateFrames(2);
    mounstruo.loadIMG(ruta_M_right,2);
    mounstruo.loadIMG(ruta_M_left,2);

    mounstruo.visible(1);

    mounstruo.Spritew(50);
    mounstruo.Spriteh(59);
    mounstruo.Spritex(0);
    mounstruo.Spritey(0);

    mounstruo.setx(200);
    mounstruo.sety(300);
    juego.addSprite(&mounstruo,"mounstruo");

    
    //backgrounds  aun sin terminar en si no son solo fodos 
    // proximamente  una clase mapa que controlar los mapas

    char ruta_background[]="background-03.bmp";
    background.load(ruta_background);
    juego.Vbackgrounds.push_back(background);


}


void inteligence(){
    // la funcion  motor.getSprite("nombre_sprite");
    //retorna un puntero al sprite llamado por su nombre
    //lo que hace que podamos controlarlo desde fuera de la clase

    //inteligencia artificial del malo se mueve de un lado a otro
    if (juego.getSprite("mounstruo")->DireccX == 0)
    {
        juego.getSprite("mounstruo")->setx(juego.getSprite("mounstruo")->getx()+ (juego.getSprite("mounstruo")->Spritew() / 2.f / 3));
        juego.getSprite("mounstruo")->seleccionarFrame(0);
        if (juego.getSprite("mounstruo")->getx() >= 600 - juego.getSprite("mounstruo")->Spritew())
        {
        juego.getSprite("mounstruo")->DireccX=1;
    }
        
        
    }

    if (juego.getSprite("mounstruo")->DireccX == 1){
        juego.getSprite("mounstruo")->setx(juego.getSprite("mounstruo")->getx()- (juego.getSprite("mounstruo")->Spritew() / 2.f / 3));
        juego.getSprite("mounstruo")->seleccionarFrame(1);
        if (juego.getSprite("mounstruo")->getx() < 1)
    {
        juego.getSprite("mounstruo")->DireccX=0;
    }
        
    }
}



int GAMELOOP(){
	int salir;
    //unsigned int ffps;
    
    while(salir!=1){
        fps.start();
        inteligence();
        juego.drawScreen();
        if(!juego.getSprite("player")->colision(juego.getSprite("mounstruo") ) ){
            salir = 1;
        }
        SDL_PollEvent(&event);
     
                if (event.type == SDL_KEYDOWN)
            {
                
                switch(event.key.keysym.sym){
                    case SDLK_RIGHT:
                    juego.getSprite("player")->seleccionarFrame(1);
                    juego.getSprite("player")->setx(juego.getSprite("player")->getx()+(juego.getSprite("player")->Spritew() / 2.f / 3));
                    break;

                    case SDLK_LEFT:
                    juego.getSprite("player")->seleccionarFrame(2);
                    juego.getSprite("player")->setx(juego.getSprite("player")->getx()-(juego.getSprite("player")->Spritew() / 2.f / 3));
                    break;

                    case SDLK_UP:
                    juego.getSprite("player")->seleccionarFrame(3);
                    juego.getSprite("player")->sety(juego.getSprite("player")->gety()- (juego.getSprite("player")->Spriteh() / 4.f / 3));
                    break;

                    case SDLK_DOWN:
                    juego.getSprite("player")->seleccionarFrame(0);
                    juego.getSprite("player")->sety(juego.getSprite("player")->gety()+ (juego.getSprite("player")->Spriteh() / 4.f / 3));
                    break;
                    case SDLK_SPACE:
                    
                    break;

                    case SDLK_q:
                    salir=1;
                    break;

                    
                }
            }


            if (event.type == SDL_KEYUP)
            {
                
                switch(event.key.keysym.sym){
                    case SDLK_RIGHT:
                    
                    break;

                    case SDLK_LEFT:
                    
                    break;

                    case SDLK_UP:
                   
                    break;

                    case SDLK_DOWN:
                    
                    break;
                    case SDLK_SPACE:
                    break;

                    
                }
            }
           

            if (event.type == SDL_MOUSEBUTTONDOWN) {
                //impresion de diacnostico del evento mouse click
                printf("mouse click en la posicion(%d,%d)\n",event.motion.x, event.motion.y);
                }



            if (event.type == SDL_QUIT)
            {
                salir = 1;
            }
            
            SDL_Delay(  16 + fps.get_ticks() );
        

    }

    SDL_Quit();
}




int main(int argc, char const *argv[])
{
    juego.FRAMES_PER_SECOND=25;//40;
    printf("cargando...\n");
    juego.video_init();
    juego.sonido_init();
    juego.titulo(aplicationName);
    initSprites();
    iniSonido();
    playSonido();
    printf("jugando\n");
 	GAMELOOP();
	return 0;
}